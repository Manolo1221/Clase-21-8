﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using App_Producto1_3;
using App_Producto1_3.Interfaces;
using App_Producto1_3.Models;



namespace App_Producto1_3
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-----  Ejercicio 1. Productos Pack y Sueltos. ------\n");

            IPrecio[] productos = new IPrecio[]
            {
                new ProductSuelto(10, "Queso (kg)", 15000.00, 0.75),
                new ProductPack(11, "Gaseosa Coca x6", 10000.00, 10),
                new ProductSuelto(12, "Manzana (kg)", 2000.00, 0.50),
                new ProductPack(13, "Galletitas Oreo x3", 8000.00, 30)
            };

            double PrecioTotalAcumulado = 0;
            foreach (IPrecio p in productos)
            { 
                Console.WriteLine(p.ToString());
                PrecioTotalAcumulado += p.CalcularPrecio();
            }

            Console.WriteLine("\n--------$Precio Total Registrado: $");
            Console.WriteLine(PrecioTotalAcumulado);
            Console.ReadKey();
        }
    }
}

        
       

