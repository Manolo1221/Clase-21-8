﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App_Producto1_3.Interfaces
{
    public interface IPrecio
    {
        double CalcularPrecio(); 
    
    }
}
