﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using App_Producto1_3.Interfaces;

namespace App_Producto1_3.Models
{
    public abstract class Product : IPrecio
    {
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public double Precio { get; set; }

        public Product(int codigo, string nombre, double precio)
        {
            Codigo = codigo;
            Nombre = nombre;
            Precio = precio;
        }
        public abstract double CalcularPrecio();
        public override string ToString()
        {
            return $"[{Codigo}] ({Nombre}) - Precio Base: {Precio}";
        }

    }
}
