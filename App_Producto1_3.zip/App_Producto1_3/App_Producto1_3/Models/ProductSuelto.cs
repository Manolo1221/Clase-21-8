﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App_Producto1_3.Models
{
    public class ProductSuelto : Product
    {
        public double Medida { get; set; }
        public ProductSuelto(int codigo, string nombre, double precio, double medida) : base(codigo, nombre, precio)
        {
            Codigo = codigo;
            Nombre = nombre;
            Precio = precio;
            Medida = medida;
        }
        public override double CalcularPrecio()
        {

            return Precio * Medida;
        }
        public override string ToString()
        {
            return $"[{base.ToString()}] - Medida ({Medida}) cm - Precio Total: {CalcularPrecio()}";
        }
    }
}
