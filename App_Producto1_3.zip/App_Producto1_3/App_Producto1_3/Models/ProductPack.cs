﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App_Producto1_3.Models
{
    public class ProductPack:Product
    { 
        public int Cantidad { get; set; }
        public ProductPack(int codigo, string nombre, double precio, int cantidad):base(codigo, nombre, precio)
        {
            Codigo = codigo;
            Nombre = nombre;
            Precio = precio;
            Cantidad = cantidad;
        }
        public override double CalcularPrecio()
        {
            
            return Precio * Cantidad;
        }
        public override string ToString()
        {
            return $"[{base.ToString()}] - Pack x ({Cantidad}) u. - Precio Total: {CalcularPrecio()}";
        }
    }
}
